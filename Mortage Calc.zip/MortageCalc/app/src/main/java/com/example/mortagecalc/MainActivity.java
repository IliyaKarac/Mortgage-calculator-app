package com.example.mortagecalc;

import android.content.Intent;
import android.os.Build;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    //setting constants for passing varibales via intent
    public static final String EXTRA_INSTALL = "Monthly instalment";
    public static final String EXTRA_ANNUAL = "Annual payment";
    public static final String EXTRA_INTEREST = "Interest paid";
    public static final String EXTRA_PAID = "Loan paid";
    public static final String EXTRA_OWED = "Money still owed";

    // only 1 instance of the class is necessary therfore global variables are used
    EditText inNum;
    double MPA = 0;
    static String rate,time,denominator;
    static double instalment,annual,interest,paid,owed;

    // making variables for active objects
    Button button;
    ArrayAdapter<CharSequence> socket;
    ArrayAdapter<CharSequence> socket2;
    ArrayAdapter<CharSequence> socket3;
    Spinner dropDown;
    Spinner dropDown2;
    Spinner dropDown3;



    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //the input number
        inNum = (EditText) findViewById(R.id.editTextNumber2);


        //making 3 spinner objects and respective input socket
        socket=ArrayAdapter.createFromResource(this,  R.array.rates,  android.R.layout.simple_spinner_item);
        socket.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        socket2=ArrayAdapter.createFromResource(this,  R.array.period,  android.R.layout.simple_spinner_item);
        socket2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        socket3=ArrayAdapter.createFromResource(this,  R.array.frequency,  android.R.layout.simple_spinner_item);
        socket3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        dropDown=(Spinner) findViewById(R.id.dropMenu);
        dropDown.setAdapter(socket);
        dropDown2=(Spinner) findViewById(R.id.dropMenu2);
        dropDown2.setAdapter(socket2);
        dropDown3=(Spinner) findViewById(R.id.dropMenu3);
        dropDown3.setAdapter(socket3);

        //the next 3 dropdown menus are the same it works by the use selecting the spinner and choosing an item on select
        //this saves user input in variable
        dropDown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent,  View view, int position, long id) {
                Toast.makeText(getBaseContext(), parent.getItemAtPosition(position) + " Selected", Toast.LENGTH_LONG).show();
                rate = parent.getItemAtPosition(position).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        dropDown2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent,  View view, int position, long id) {
                Toast.makeText(getBaseContext(), parent.getItemAtPosition(position) + " Selected", Toast.LENGTH_LONG).show();
                time = parent.getItemAtPosition(position).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        dropDown3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent,  View view, int position, long id) {
                Toast.makeText(getBaseContext(), parent.getItemAtPosition(position) + " Selected", Toast.LENGTH_LONG).show();
                denominator = parent.getItemAtPosition(position).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        //button does 3 thing onClick: takes user input from text box, runs calculate function and opens next activity
        button =(Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MPA = Double.valueOf(inNum.getText().toString());
                calculate();




                openMain3Activity();
            }
        });

    }

    //calculate is responsible for calculating the mortgage values
    public void calculate(){

        //first it changes user input into usable values
        double R = 0;
        if(rate.equals("2%")){
            R = 0.02;
        }
        else if(rate.equals("2.25%")){
            R = 0.0225;
        }
        else if(rate.equals("2.50%")){
            R = 0.025;
        }
        else if(rate.equals("2.75%")){
            R = 0.0275;
        }
        else if(rate.equals("3%")){
            R = 0.03;
        }
        else if(rate.equals("3.25%")){
            R = 0.0325;
        }
        else if(rate.equals("3.50%")){
            R = 0.035;
        }
        else if(rate.equals("3.75%")){
            R = 0.0375;
        }
        else if(rate.equals("4%")){
            R = 0.04;
        }
        else if(rate.equals("4.25%")){
            R = 0.0425;
        }
        //-------------------------------------------------------------------

        double t = 0;
        if(time.equals("1 Year")){
            t=1;
        }
        else if(time.equals("2 Years")){
            t=2;
        }
        else if(time.equals("3 Years")){
            t=3;
        }
        else if(time.equals("4 Years")){
            t=4;
        }
        else if(time.equals("5 Years")){
            t=5;
        }
        else if(time.equals("6 Years")){
            t=6;
        }
        else if(time.equals("7 Years")){
            t=7;
        }
        else if(time.equals("8 Years")){
            t=8;
        }
        else if(time.equals("9 Years")){
            t=9;
        }
        else if(time.equals("10 Years")){
            t=10;
        }
        else if(time.equals("15 Years")){
            t=15;
        }
        else if(time.equals("20 Years")){
            t=20;
        }
        else if(time.equals("25 Years")){
            t=25;
        }
        else if(time.equals("30 Years")){
            t=30;
        }
        //-------------------------------------------------------------------
        double denom = 0;
        if(denominator.equals("Weekly")){
            denom=52;
        }
        else if(denominator.equals("Bi-weekly")){
            denom=26;
        }
        else if(denominator.equals("Monthly")){
            denom=12;
        }


        //then it uses a math equation to find all the mortgage values
        double n = t*denom;  //amount of times of compounding
        double r = R/denom;  //rate per compound
        double tmp = Math.pow((1+r),n); //tmp variable just for exponent calculation

        //All the *100 then round then /100 is to keep 2 decimal places
        instalment = (Math.round((100*MPA*r*tmp)/(tmp-1)))/100.0; //find the amount of installment paid every pay period
        annual = (Math.round(100*instalment*denom))/100.0; //amount paid in a year
        interest = (Math.round(100*MPA*R))/100.0; //interest paid in a year
        paid = (Math.round(100*(annual -interest))/100.0); //principle paid off in a year
        owed = (Math.round(100*(MPA - paid)))/100.0; //principle amount still owed
    }

    //opening next xml page
    public void openMain3Activity(){
        //making new intent instance
        Intent intent = new Intent(this, Main3Activity.class);
        //defining variables that will be passed through intent
        intent.putExtra(EXTRA_INSTALL,instalment);
        intent.putExtra(EXTRA_ANNUAL,annual);
        intent.putExtra(EXTRA_INTEREST,interest);
        intent.putExtra(EXTRA_PAID,paid);
        intent.putExtra(EXTRA_OWED,owed);
        //opening next page
        startActivity(intent);
    }
}