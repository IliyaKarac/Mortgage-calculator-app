package com.example.mortagecalc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        Button button2;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        //recieving variables from previous page
        Intent intent=getIntent();
        double monthly=intent.getDoubleExtra(MainActivity.EXTRA_INSTALL,0);
        double annual=intent.getDoubleExtra(MainActivity.EXTRA_ANNUAL,0);
        double interest=intent.getDoubleExtra(MainActivity.EXTRA_INTEREST,0);
        double paid=intent.getDoubleExtra(MainActivity.EXTRA_PAID,0);
        double owed=intent.getDoubleExtra(MainActivity.EXTRA_OWED,0);

        //setting up variables on textviews
        TextView text1 =(TextView) findViewById(R.id.textView5);
        TextView text2 =(TextView) findViewById(R.id.textView6);
        TextView text3 =(TextView) findViewById(R.id.textView7);
        TextView text4 =(TextView) findViewById(R.id.textView8);
        TextView text5 =(TextView) findViewById(R.id.textView9);

        //setting values on the text view
        text1.setText(String.valueOf(monthly));
        text2.setText(String.valueOf(annual));
        text3.setText(String.valueOf(interest));
        text4.setText(String.valueOf(paid));
        text5.setText(String.valueOf(owed));





        //button to return to next page
        button2 =(Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainActivity();
            }
        });
    }
    public void openMainActivity(){
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);
    }
}